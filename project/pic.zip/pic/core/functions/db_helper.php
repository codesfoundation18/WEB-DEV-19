<?php 

function get($dbCon, $table) 
{
	// 
}

